package com.myapp;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.Test;

import junit.framework.Assert;

public class BinarySearchTest {

	BinarySearch br = new BinarySearch();
	int arr[] = { 2, 3, 4, 10, 40 };
	int l = 0;
	int x = 10;
	int r = arr.length;
	int expected = 3;

	@Test
	public void testBinarySearch() {
		int A = br.binarySearch(arr, l, r, x);
		Assert.assertEquals(expected, A);

	}
}

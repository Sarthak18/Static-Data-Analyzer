package com.myapp;

import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.Test;

public class RotateRightTest {

	RotateRight ob = new RotateRight();
	int arr[] = { 1, 2, 3, 4, 5 };
	int expectedArr[] = { 3, 4, 5, 1, 2 };
	int num = 3;

	@Test
	public void testRotateArray() {
		int A[] = ob.rotateArray(arr, num);

		assertTrue(Arrays.equals(expectedArr, A));

	};

}

package com.myapp;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import junit.framework.Assert;

public class LongestRepeatingSequenceTest {
	LongestRepeatingSequence lc = new LongestRepeatingSequence();

	String expected = "bdf";

	@Test
	public void testLongestRepeatingSequence() {
		String str = "acbdfghybdf";
		String A = "";
		String lrs = "";
		int n = str.length();
		for (int i = 0; i < n; i++) {
			for (int j = i + 1; j < n; j++) {
				// Checks for the largest common factors in every substring
				A = lc.lcp(str.substring(i, n), str.substring(j, n));
				if (A.length() > lrs.length())
					lrs = A;
			}

		}
		assertEquals(expected, lrs);
	}
}

package com.myapp;

import java.util.*;

public class ReverseString {
	public static void main(String args[]) {
		String reverse = "";
		String original = "Hello";

		int length = original.length();
		ReverseString ob = new ReverseString();
		reverse = ob.reverse(reverse, original, length);

		System.out.println("Reverse of the string: " + reverse);
	}

	public String reverse(String reverse, String original, int length) {
		for (int i = length - 1; i >= 0; i--)
			reverse = reverse + original.charAt(i);
		return reverse;
	}
}
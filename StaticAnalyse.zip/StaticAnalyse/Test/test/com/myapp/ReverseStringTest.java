package com.myapp;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;

import org.junit.Test;

public class ReverseStringTest {
	ReverseString ob = new ReverseString();
	String A="";
	String original = "Hello";
	String expected = "olleH";
	int length = 5;

	@Test
	public void testReverseString() {
		String actual = ob.reverse(A, original, length);
		assertEquals(expected, actual);
	}

}

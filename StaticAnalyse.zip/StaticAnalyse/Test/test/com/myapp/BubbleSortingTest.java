package com.myapp;

import org.junit.Test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;

public class BubbleSortingTest {

	BubbleSorting ob = new BubbleSorting();
	int arr[] = { 64, 34, 25, 12, 22, 11, 90 };
	int expectedArr[] = { 11, 12, 22, 25, 34, 64, 90 };

	@Test
	public void testBubbleSort() {
		int A[] = ob.bubbleSort(arr);

		assertTrue(Arrays.equals(expectedArr, arr));

	}
}
